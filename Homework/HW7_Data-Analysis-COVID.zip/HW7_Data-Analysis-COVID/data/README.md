Pulled from https://github.com/CryptoKass/ncov-data

#Summary
A timeframe from 1/22 to 2/8 that covers confirmed cases, deaths, and
recovered.  Taken from the README of this dataset: “There are a total of 60371
comfirmed cases worldwide, with 59804 in Mainland China. Sadly at least 1367
people have died from this virus.” This dataset captures the most recent data
from global statistics in a csv containing data for the whole world on
coronavirus.

#Potential Questions that can be asked about this dataset
- Ask about trends and spikes- why sometimes data clumps together, what this
  means about international communication
- What does the data do well? Not do well?
  - Gives a good idea of how the world overall is dealing with CoViD
  - Fails to go more into specifics so unclear how safe viewers are

