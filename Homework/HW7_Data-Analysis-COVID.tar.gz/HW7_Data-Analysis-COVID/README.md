# HOMEWORK 7: CoViD-19 Data Analysis

## NAME
< insert name >

## ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT
< insert # hours >

## SHORT ANSWERS (1-3 PARAGRAPHS EACH)
1. Examine the data. Describe its growth over the 2 week period. Is the trend linear? Why or why not?
< insert answer >

2. What biases could factor into the data? What are these biases and how does this affect your conclusions?
< insert answer >

3. Consider Virginia Eubanks’s book, especially Chapter 4, “The Allegheny Algorithm.” How are categories and decisions about parenting, childcare, and appropriate care constructed in Pittsburgh? What parallels do you see between that example and the data presented in this assignment?
< insert answer >

## MISC. COMMENTS TO GRADER
Optional, please be concise!
